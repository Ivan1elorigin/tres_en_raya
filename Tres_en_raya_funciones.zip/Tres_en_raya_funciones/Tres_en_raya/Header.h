#pragma once
//Librer�as

#include <stdio.h>
#include <stdlib.h>

//Prototipos

void iniciamos(int[3][3]);
void tirar(int, int[3][3]);
void imprime(int[3][3]);
int evaluamos(int[3][3]);
int jugador();
int maquina();
