#include "Header.h"

//Funciones


void iniciamos(int tablero[3][3]) {
	int i = 0, j = 0;
	//Iniciamos el tablero con 0.


	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++) {
			tablero[i][j] = 0;
		}
	}

}
void tirar(int modo, int tablero[3][3]) {
	int  inputi = 0, inputj = 0, flag = 0;
	if (modo == 0) {
		do {

			//Tira el jugador
			printf("Jugador, escoga donde quiere poner una ficha: \n");

			printf("Seleccione i (0,1,2): ");
			scanf_s("%d", &inputi);

			printf("Seleccione j (0,1,2): ");
			scanf_s("%d", &inputj);

			if (tablero[inputi][inputj] == 0) {

				tablero[inputi][inputj] = 2;
				inputi = 0;
				inputj = 0;
				flag = 1;
			}
			else {
				printf("La posicion ya esta ocupada.\n");
			}

		} while (flag == 0);
		flag = 0;
	}
	else {
		//Ahora tira la m�quina
		do {

			inputi = (rand() % 3);
			inputj = (rand() % 3);

			if (tablero[inputi][inputj] == 0) {
				tablero[inputi][inputj] = 1;
				flag = 1;
			}

		} while (flag == 0);
		flag = 0;
	}

}
void imprime(int tablero[3][3]) {
	int i = 0, j = 0;
	//Imprime
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++) {
			printf("| %d |", tablero[i][j]);
		}
		printf("\n");
	}
}
int evaluamos(int tablero[3][3]) {
	int i = 0, j = 0;
	//Por filas


	for (i = 0; i < 3; i++) {
		if ((tablero[i][0] == 1 && tablero[i][1] == 1 && tablero[i][2] == 1)) {
			printf("Gano la maquina.\n");
			return 1;
		}

		if ((tablero[i][0] == 2 && tablero[i][1] == 2 && tablero[i][2] == 2)) {
			printf("Gano el jugador.\n");
			return 1;
		}
	}


	//Por columnas


	for (i = 0; i < 3; i++) {
		if ((tablero[0][i] == 1 && tablero[1][i] == 1 && tablero[2][i] == 1)) {
			printf("Gano la maquina.\n");
			return 1;
		}

		if ((tablero[0][i] == 2 && tablero[1][i] == 2 && tablero[2][i] == 2)) {
			printf("Gano el jugador.\n");
			return 1;
		}

	}


	//Evaluamos las diagonales principales



	if ((tablero[0][0] == 1 && tablero[1][1] == 1 && tablero[2][2] == 1)) {
		printf("Gano la maquina.\n");
		return 1;

	}

	if ((tablero[0][0] == 2 && tablero[1][1] == 2 && tablero[2][2] == 2)) {
		printf("Gano el jugador.\n");
		return 1;

	}
	//Evaluamos las diagonales secundarias

	if ((tablero[2][0] == 1 && tablero[1][1] == 1 && tablero[0][2] == 1)) {
		printf("Gano la maquina.\n");
		return 1;

	}

	if ((tablero[2][0] == 2 && tablero[1][1] == 2 && tablero[0][2] == 2)) {
		printf("Gano el jugador.\n");
		return 1;

	}

}


//Funciones que imprimen
int jugador() {
	printf("Gano el jugador");
	return 9;
}

int maquina() {
	printf("Gano la maquina");
	return 9;
}