#include "Header.h"
//Funci�n main
int main() {

	int tablero[3][3], turnos = 0, big = 0, modo = 1, contmac=0, contjug=0;
	char resp = 'n';


	srand(time(NULL));

	do {
		//Empieza quien ha perdido la anterior partida o el pen�ltimo jugador en tirar (en caso de empate).

		iniciamos(tablero);
		printf("\nEste es el tablero inicial\n");
		imprime(tablero);
		printf("\n\n");

		for (turnos = 0; turnos < 9; turnos++) {

			//alternador, en cada tirada se cambia de modo. Modo 0 --> Jugador | Modo 1 --> Maquina

			if (modo == 1) {
				modo = 0;
			}
			else {
				modo = 1;
			}

			tirar(modo, tablero);
			imprime(tablero);
			printf("\n\n\n"); //Imprimimos varios espacios
			
			if (evaluamos(tablero) == 1) {
				big = 1;
				if (modo == 0) {
					turnos = jugador();
					contjug += 1;
				}
				else {
					turnos = maquina();
					contmac += 1;
				}
			}


		}
		





		// Si a la bandera big no se le ha asignado el valor 1 en ning�n momento significa que se ha producido un empate.
		if (big == 0) {
			printf("Se ha producido un empate.\n");
		}

		big = 0; //Limpiamos la flag para usarla m�s tarde.

		printf("Quieres volver a jugar? (s/n)");
		scanf_s(" %c", &resp);

	} while (resp == 's' || resp == 'S');

	printf("\nEl jugador ha ganado %d veces.\n", contjug);
	printf("\nLa maquina ha ganado %d veces. \n", contmac);

	system("pause");
	return 0;


}

